# Farming-Assistance-Portal
An easy-to-use assistance portal for farmers or anyone who is connected to the agriculture industry, to get crop recommendations, analyze current and future crop prices, weather forecasts, and available government schemes so that they can use the data to make better and more informed decisions.
